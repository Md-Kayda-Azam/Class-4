


let agecal = (name, year) => {

    return` Hi ${name}, your are ${2021- year} your old`;
}

let name =prompt('please your name?');
let year =parseInt(prompt('please your Birthday year'));

console.log (agecal(name, year));